public class ariketak {
    public static void main(String[] args) throws Exception {
        java.util.Scanner sc = new java.util.Scanner(System.in);

        /* 1. Ariketa */
        System.out.print("agertzenDaA:");
        String agertzenDaA = sc.next();

        if (agertzenDaA(agertzenDaA)) {
            System.out.println("Agertzen da.");
        } else {
            System.out.println("Ez da agertzen.");
        }

        /* 2. Ariketa */
        System.out.println("alderantziz:");
        String alderantziz = sc.next();
        String alderantzizBuelta = alderantziz(alderantziz);
        System.out.println(alderantzizBuelta);

        /* 3. Ariketa */
        System.out.println("agertzenDaAA:");
        String agertzenDaAA = sc.next();

        if (agertzenDaAA(agertzenDaAA)) {
            System.out.println("Agertzen da.");
        } else {
            System.out.println("Ez da agertzen.");
        }

        /* 4. Ariketa */
        System.out.println("agerpenKopuruaA:");
        String agerpenKopuruaA = sc.next();
        int kopurua = agerpenKopuruaA(agertzenDaA);
        System.out.println("A eltra " + kopurua + " aldiz agertu da.");

        /* 5. Ariketa */
        System.out.println("berredura:");
        int n = sc.nextInt();
        int emaitza = berredura(n);
        System.out.println("2^" + n + " = " + emaitza);
    }

    /* 1. Ariketa */
    public static boolean agertzenDaA(String letraA) {
        return letraA.toLowerCase().contains("a");
    }

    /* 2. Ariketa */
    public static String alderantziz(String ald) {
        return new StringBuilder(ald).reverse().toString();
    }

    /* 3. Ariketa */
    public static boolean agertzenDaAA(String agertzenDaAA) {
        return agertzenDaAA.toLowerCase().contains("aa");
    }

    /* 4. Ariketa */
    public static int agerpenKopuruaA(String letraA) {
        int kopurua = 0;
        for (char karakterea : letraA.toLowerCase().toCharArray()) {
            if (karakterea == 'a') {
                kopurua++;
            }
        }
        return kopurua;
    }

    /* 5. Ariketa */
    public static int berredura(int n) {
        return (int) Math.pow(2, n);
    }
}
